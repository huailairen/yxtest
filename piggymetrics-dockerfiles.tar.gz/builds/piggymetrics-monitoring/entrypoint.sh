#!/bin/bash
set -e 
echo $LBIP rabbitmq >> /etc/hosts
echo $LBIP data-mongodb >> /etc/hosts
echo $LBIP config >> /etc/hosts
echo $LBIP registry >> /etc/hosts
echo $LBIP gateway >> /etc/hosts
echo $LBIP auth-service >> /etc/hosts
echo $LBIP account-service >> /etc/hosts
echo $LBIP statistics-service >> /etc/hosts
echo $LBIP notification-service >> /etc/hosts
echo $LBIP monitoring >> /etc/hosts
exec "$@"
